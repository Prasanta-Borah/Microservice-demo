package com.apigateway.springCloudAPIgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudApIgatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudApIgatewayApplication.class, args);
	}

}
